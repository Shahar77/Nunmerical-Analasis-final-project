"""
Newton-Raphson Method for solving nonlinear equations.
"""

import matplotlib.pyplot as plt
import numpy as np


def newton_raphson(f, df, x0, tol=1e-6, max_iter=100):
    """
    Applies the Newton-Raphson method to find a root of f starting from x0.

    Parameters:
        f (function): The function f(x).
        df (function): The derivative f'(x).
        x0 (float): Initial guess.
        tol (float): Tolerance for convergence.
        max_iter (int): Maximum number of iterations.

    Returns:
        root (float): Approximate root.
        iterations (list): List of (x_n, f(x_n)) values at each step.
    """
    x = x0
    iterations = [(x, f(x))]

    for _ in range(max_iter):
        fx = f(x)
        dfx = df(x)

        if dfx == 0:
            raise ZeroDivisionError("Derivative is zero. Cannot proceed.")

        x_new = x - fx / dfx
        iterations.append((x_new, f(x_new)))

        if abs(x_new - x) < tol:
            return x_new, iterations

        x = x_new

    raise RuntimeError("Newton-Raphson method did not converge.")


def plot_newton(f, root, iterations, x_range=None):
    """
    Plots the function and iterations of Newton-Raphson method.

    Parameters:
        f (function): The function f(x).
        root (float): The root found.
        iterations (list): Iteration points.
        x_range (tuple): Optional range (xmin, xmax) for plotting.
    """
    if not x_range:
        xs = [x for x, _ in iterations]
        margin = (max(xs) - min(xs)) * 0.2 or 1
        x_range = (min(xs) - margin, max(xs) + margin)

    x_vals = np.linspace(*x_range, 400)
    y_vals = f(x_vals)

    plt.figure(figsize=(10, 6))
    plt.plot(x_vals, y_vals, label="f(x)")
    plt.axhline(0, color='gray', linestyle='--')

    for x_n, _ in iterations:
        plt.plot(x_n, f(x_n), 'ro', alpha=0.3)

    plt.plot(root, f(root), 'go', label=f'Root ≈ {root:.6f}', markersize=10)
    plt.title("Newton-Raphson Method")
    plt.xlabel("x")
    plt.ylabel("f(x)")
    plt.legend()
    plt.grid(True)
    plt.show()


# Example usage
if __name__ == "__main__":
    # Function and its derivative
    f = lambda x: x**3 - x - 2
    df = lambda x: 3*x**2 - 1

    x0 = 1.5
    tol = 1e-6

    try:
        root, iters = newton_raphson(f, df, x0, tol)
        print(f"Approximate root: {root}")
        print(f"Total iterations: {len(iters)}")
        plot_newton(f, root, iters)

    except Exception as e:
        print("Error:", e)
