"""
Lagrange Polynomial Interpolation
"""

import numpy as np
import matplotlib.pyplot as plt


def lagrange_interpolation(x_points, y_points, x_val):
    """
    Computes the Lagrange interpolated value at x_val based on the data points.

    Parameters:
        x_points (list or ndarray): x coordinates of known points
        y_points (list or ndarray): y coordinates of known points
        x_val (float): The x-value at which to evaluate the interpolated polynomial

    Returns:
        float: The interpolated value f(x_val)
    """
    n = len(x_points)
    result = 0

    for i in range(n):
        term = y_points[i]
        for j in range(n):
            if i != j:
                term *= (x_val - x_points[j]) / (x_points[i] - x_points[j])
        result += term

    return result


def plot_lagrange(x_points, y_points, resolution=200):
    """
    Plots the Lagrange interpolating polynomial and the original points.

    Parameters:
        x_points (list or ndarray): x coordinates of known points
        y_points (list or ndarray): y coordinates of known points
        resolution (int): Number of points in the interpolation plot
    """
    x_min, x_max = min(x_points), max(x_points)
    x_vals = np.linspace(x_min, x_max, resolution)
    y_vals = [lagrange_interpolation(x_points, y_points, x) for x in x_vals]

    plt.figure(figsize=(10, 6))
    plt.plot(x_vals, y_vals, label="Lagrange Polynomial", color="blue")
    plt.scatter(x_points, y_points, color="red", label="Given Points", zorder=5)
    plt.title("Lagrange Interpolation")
    plt.xlabel("x")
    plt.ylabel("f(x)")
    plt.legend()
    plt.grid(True)
    plt.show()


# Example usage
if __name__ == "__main__":
    x_pts = [0, 1, 2, 3]
    y_pts = [1, 2, 0, 5]

    x_val = 1.5
    interpolated = lagrange_interpolation(x_pts, y_pts, x_val)
    print(f"Interpolated value at x = {x_val} is {interpolated:.6f}")
    plot_lagrange(x_pts, y_pts)
