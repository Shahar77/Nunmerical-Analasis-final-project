"""
Submenu for Interpolation Methods
"""

from methods.lagrange import lagrange_interpolation, plot_lagrange
from methods.neville import neville_interpolation, plot_neville
from methods.cubic_spline import plot_cubic_spline


def get_points():
    """
    קולט מהמשתמשת נקודות (x_i, y_i) עבור אינטרפולציה
    """
    n = int(input("Enter number of data points: "))
    x_points = list(map(float, input("Enter x values (space-separated): ").split()))
    y_points = list(map(float, input("Enter y values (space-separated): ").split()))

    if len(x_points) != n or len(y_points) != n:
        print("Error: Number of x and y values must match.")
        return get_points()

    return x_points, y_points


def interpolation_menu():
    print("\n📈 Interpolation Methods")
    print("1. Lagrange Interpolation")
    print("2. Neville Interpolation")
    print("3. Cubic Spline Interpolation")
    print("0. Return to Main Menu")

    choice = input("Choose method: ").strip()

    if choice in ["1", "2", "3"]:
        x_points, y_points = get_points()

    if choice == "1":
        x_val = float(input("Enter x value to interpolate: "))
        try:
            result = lagrange_interpolation(x_points, y_points, x_val)
            print(f"✅ Interpolated value at x = {x_val} is {result:.6f}")
            plot_lagrange(x_points, y_points)
        except Exception as e:
            print("Error:", e)

    elif choice == "2":
        x_val = float(input("Enter x value to interpolate: "))
        try:
            result, table = neville_interpolation(x_points, y_points, x_val)
            print(f"✅ Interpolated value at x = {x_val} is {result:.6f}")
            print("Neville Table:")
            for row in table:
                print(["{:.4f}".format(val) for val in row if val != 0.0])
            plot_neville(x_points, y_points)
        except Exception as e:
            print("Error:", e)

    elif choice == "3":
        try:
            plot_cubic_spline(x_points, y_points)
        except Exception as e:
            print("Error:", e)

    elif choice == "0":
        return

    else:
        print("Invalid choice.")
        interpolation_menu()
