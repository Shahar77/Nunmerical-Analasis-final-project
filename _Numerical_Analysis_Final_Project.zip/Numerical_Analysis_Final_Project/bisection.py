"""
Bisection Method for solving nonlinear equations.
"""

import matplotlib.pyplot as plt
import numpy as np


def bisection_method(f, a, b, tol=1e-6, max_iter=100):
    """
    Applies the Bisection method to find a root of f in the interval [a, b].

    Parameters:
        f (function): The function for which to find the root.
        a (float): The start of the interval.
        b (float): The end of the interval.
        tol (float): Tolerance for convergence.
        max_iter (int): Maximum number of iterations.

    Returns:
        root (float): Approximate root.
        iterations (list): List of (a, b, c, f(c)) at each step.
    """
    if np.sign(f(a)) == np.sign(f(b)):
        raise ValueError("Function must have opposite signs at endpoints a and b.")

    iterations = []
    for i in range(max_iter):
        c = (a + b) / 2
        fc = f(c)
        iterations.append((a, b, c, fc))

        if abs(fc) < tol or abs(b - a) < tol:
            return c, iterations

        if np.sign(f(a)) != np.sign(fc):
            b = c
        else:
            a = c

    raise RuntimeError("Bisection method did not converge.")


def plot_bisection(f, a, b, root, iterations):
    """
    Plots the function and highlights the root and iterations.

    Parameters:
        f (function): The function being analyzed.
        a (float): Start of x-range.
        b (float): End of x-range.
        root (float): The root found.
        iterations (list): Iteration data to plot.
    """
    x = np.linspace(a, b, 400)
    y = f(x)

    plt.figure(figsize=(10, 6))
    plt.plot(x, y, label="f(x)")
    plt.axhline(0, color='gray', linestyle='--')

    # Plot intermediate midpoints
    for i, (_, _, c, _) in enumerate(iterations):
        plt.plot(c, f(c), 'ro', alpha=0.3)

    # Final root
    plt.plot(root, f(root), 'go', label=f'Root ≈ {root:.6f}', markersize=10)

    plt.title("Bisection Method")
    plt.xlabel("x")
    plt.ylabel("f(x)")
    plt.legend()
    plt.grid(True)
    plt.show()


# Example usage
if __name__ == "__main__":
    # Define the function
    f = lambda x: x**3 - x - 2

    # Interval and tolerance
    a = 1
    b = 2
    tol = 1e-6

    try:
        root, iters = bisection_method(f, a, b, tol)
        print(f"Approximate root: {root}")
        print(f"Total iterations: {len(iters)}")
        plot_bisection(f, a, b, root, iters)

    except Exception as e:
        print("Error:", e)
