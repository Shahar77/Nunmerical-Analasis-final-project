"""
LU Decomposition for solving systems of linear equations: A = LU
"""

import numpy as np


def lu_decomposition(A):
    """
    Performs LU Decomposition using Doolittle's method (no pivoting).

    Parameters:
        A (ndarray): Coefficient matrix (n x n)

    Returns:
        L (ndarray): Lower triangular matrix
        U (ndarray): Upper triangular matrix
    """
    n = A.shape[0]
    L = np.zeros_like(A, dtype=float)
    U = np.zeros_like(A, dtype=float)

    for i in range(n):
        # Upper Triangular
        for k in range(i, n):
            U[i, k] = A[i, k] - sum(L[i, j] * U[j, k] for j in range(i))

        # Lower Triangular
        L[i, i] = 1  # Diagonal = 1
        for k in range(i+1, n):
            if U[i, i] == 0:
                raise ValueError("Zero pivot encountered!")
            L[k, i] = (A[k, i] - sum(L[k, j] * U[j, i] for j in range(i))) / U[i, i]

    return L, U


def forward_substitution(L, b):
    """
    Solves Ly = b for y using forward substitution.

    Parameters:
        L (ndarray): Lower triangular matrix
        b (ndarray): Right-hand side vector

    Returns:
        y (ndarray): Intermediate vector
    """
    n = len(b)
    y = np.zeros(n)

    for i in range(n):
        y[i] = b[i] - np.dot(L[i, :i], y[:i])
    return y


def back_substitution(U, y):
    """
    Solves Ux = y for x using back substitution.

    Parameters:
        U (ndarray): Upper triangular matrix
        y (ndarray): Intermediate vector

    Returns:
        x (ndarray): Solution vector
    """
    n = len(y)
    x = np.zeros(n)

    for i in range(n-1, -1, -1):
        x[i] = (y[i] - np.dot(U[i, i+1:], x[i+1:])) / U[i, i]
    return x


def solve_with_lu(A, b):
    """
    Solves Ax = b using LU decomposition.

    Parameters:
        A (ndarray): Coefficient matrix
        b (ndarray): Right-hand side vector

    Returns:
        x (ndarray): Solution vector
    """
    L, U = lu_decomposition(A)
    y = forward_substitution(L, b)
    x = back_substitution(U, y)
    return x


# Example usage
if __name__ == "__main__":
    A = np.array([[2, -1, -2],
                  [-4, 6, 3],
                  [-4, -2, 8]], dtype=float)
    b = np.array([-2, 9, -5], dtype=float)

    try:
        x = solve_with_lu(A, b)
        print("Solution vector x:")
        print(x)
    except Exception as e:
        print("Error:", e)
