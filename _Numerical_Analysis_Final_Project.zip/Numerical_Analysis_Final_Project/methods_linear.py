"""
Submenu for Linear Systems Solvers
"""

import numpy as np
from methods.gaussian_elimination import gaussian_elimination
from methods.lu_decomposition import solve_with_lu
from methods.jacobi import jacobi_method
from methods.gauss_seidel import gauss_seidel


def get_matrix_input():
    """
    קולט מהמשתמשת מטריצת מקדמים A ווקטור אגף ימין b
    """
    n = int(input("Enter the size of the system (n for nxn): "))
    print("Enter matrix A row by row, separated by spaces:")
    A = np.array([list(map(float, input(f"Row {i + 1}: ").split())) for i in range(n)])
    b = np.array(list(map(float, input("Enter vector b (space-separated): ").split())))
    return A, b


def linear_menu():
    print("\n🧮 Linear Systems Solvers")
    print("1. Gaussian Elimination")
    print("2. LU Decomposition")
    print("3. Jacobi Iterative Method")
    print("4. Gauss-Seidel Iterative Method")
    print("0. Return to Main Menu")

    choice = input("Choose method: ").strip()

    if choice in ["1", "2", "3", "4"]:
        A, b = get_matrix_input()

    if choice == "1":
        try:
            x = gaussian_elimination(A, b)
            print("✅ Solution x:", x)
        except Exception as e:
            print("Error:", e)

    elif choice == "2":
        try:
            x = solve_with_lu(A, b)
            print("✅ Solution x:", x)
        except Exception as e:
            print("Error:", e)

    elif choice == "3":
        try:
            x, history = jacobi_method(A, b)
            print("✅ Solution x:", x)
            print(f"Iterations: {len(history)}")
        except Exception as e:
            print("Error:", e)

    elif choice == "4":
        try:
            x, history = gauss_seidel(A, b)
            print("✅ Solution x:", x)
            print(f"Iterations: {len(history)}")
        except Exception as e:
            print("Error:", e)

    elif choice == "0":
        return

    else:
        print("Invalid choice.")
        linear_menu()
