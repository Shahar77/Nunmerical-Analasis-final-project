"""
Jacobi Iterative Method for solving systems of linear equations.
"""

import numpy as np


def jacobi_method(A, b, x0=None, tol=1e-6, max_iter=100):
    """
    Solves Ax = b using the Jacobi iterative method.

    Parameters:
        A (ndarray): Coefficient matrix (n x n)
        b (ndarray): Right-hand side vector (n)
        x0 (ndarray): Initial guess (default: zero vector)
        tol (float): Convergence tolerance
        max_iter (int): Maximum number of iterations

    Returns:
        x (ndarray): Approximate solution
        history (list): Iteration history of solution vectors
    """
    n = A.shape[0]
    x = np.zeros(n) if x0 is None else x0.copy()
    history = [x.copy()]

    for _ in range(max_iter):
        x_new = np.zeros_like(x)
        for i in range(n):
            sum_ax = np.dot(A[i, :i], x[:i]) + np.dot(A[i, i+1:], x[i+1:])
            x_new[i] = (b[i] - sum_ax) / A[i, i]

        history.append(x_new.copy())
        if np.linalg.norm(x_new - x, ord=np.inf) < tol:
            return x_new, history

        x = x_new

    raise RuntimeError("Jacobi method did not converge.")


# Example usage
if __name__ == "__main__":
    A = np.array([[10, -1, 2],
                  [-1, 11, -1],
                  [2, -1, 10]], dtype=float)
    b = np.array([6, 25, -11], dtype=float)
    x0 = np.zeros(3)

    try:
        solution, steps = jacobi_method(A, b, x0)
        print("Solution vector x:")
        print(solution)
        print(f"Total iterations: {len(steps)}")
    except Exception as e:
        print("Error:", e)
