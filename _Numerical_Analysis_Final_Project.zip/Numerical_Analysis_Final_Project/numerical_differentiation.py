"""
Numerical Differentiation Methods: Forward, Backward, and Central Differences
"""

import numpy as np
import matplotlib.pyplot as plt


def forward_difference(f, x, h=1e-5):
    """
    Computes first derivative using the forward difference method.

    Parameters:
        f (function): Function to differentiate
        x (float): Point at which to evaluate derivative
        h (float): Step size

    Returns:
        float: Approximate derivative f'(x)
    """
    return (f(x + h) - f(x)) / h


def backward_difference(f, x, h=1e-5):
    """
    Computes first derivative using the backward difference method.

    Returns:
        float: Approximate derivative f'(x)
    """
    return (f(x) - f(x - h)) / h


def central_difference(f, x, h=1e-5):
    """
    Computes first derivative using the central difference method.

    Returns:
        float: Approximate derivative f'(x)
    """
    return (f(x + h) - f(x - h)) / (2 * h)


def plot_derivative(f, x, h=1e-5):
    """
    Plots the function f and the tangent line at point x using central difference.

    Parameters:
        f (function): Function to differentiate
        x (float): Point at which to evaluate the derivative
        h (float): Step size
    """
    derivative = central_difference(f, x, h)
    x_vals = np.linspace(x - 1, x + 1, 400)
    y_vals = f(x_vals)
    tangent_line = derivative * (x_vals - x) + f(x)

    plt.figure(figsize=(10, 6))
    plt.plot(x_vals, y_vals, label="f(x)")
    plt.plot(x_vals, tangent_line, '--', label=f"Tangent at x={x}", color="red")
    plt.scatter([x], [f(x)], color="green", zorder=5, label="Point of differentiation")
    plt.title("Numerical Derivative (Tangent Line)")
    plt.xlabel("x")
    plt.ylabel("f(x)")
    plt.legend()
    plt.grid(True)
    plt.show()


# Example usage
if __name__ == "__main__":
    f = lambda x: np.sin(x)
    x0 = np.pi / 4

    fwd = forward_difference(f, x0)
    bwd = backward_difference(f, x0)
    ctr = central_difference(f, x0)

    print(f"Forward Difference: {fwd:.6f}")
    print(f"Backward Difference: {bwd:.6f}")
    print(f"Central Difference: {ctr:.6f}")

    plot_derivative(f, x0)
