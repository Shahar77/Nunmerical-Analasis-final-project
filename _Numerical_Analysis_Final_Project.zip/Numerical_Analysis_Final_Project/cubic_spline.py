"""
Cubic Spline Interpolation
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline


def cubic_spline_interpolation(x_points, y_points, resolution=200):
    """
    Applies natural cubic spline interpolation and returns interpolated x and y.

    Parameters:
        x_points (list): x coordinates of known points
        y_points (list): y coordinates of known points
        resolution (int): Number of interpolation points

    Returns:
        x_vals (ndarray): Interpolated x values
        y_vals (ndarray): Interpolated y values
    """
    cs = CubicSpline(x_points, y_points, bc_type='natural')
    x_vals = np.linspace(min(x_points), max(x_points), resolution)
    y_vals = cs(x_vals)
    return x_vals, y_vals


def plot_cubic_spline(x_points, y_points):
    """
    Plots cubic spline interpolation along with the original points.

    Parameters:
        x_points (list): x coordinates of known points
        y_points (list): y coordinates of known points
    """
    x_vals, y_vals = cubic_spline_interpolation(x_points, y_points)

    plt.figure(figsize=(10, 6))
    plt.plot(x_vals, y_vals, label="Cubic Spline", color="green")
    plt.scatter(x_points, y_points, color="red", label="Given Points", zorder=5)
    plt.title("Cubic Spline Interpolation")
    plt.xlabel("x")
    plt.ylabel("f(x)")
    plt.legend()
    plt.grid(True)
    plt.show()


# Example usage
if __name__ == "__main__":
    x_pts = [0, 1, 2, 3, 4]
    y_pts = [1, 2, 0, 2, 3]

    try:
        plot_cubic_spline(x_pts, y_pts)
    except Exception as e:
        print("Error:", e)
