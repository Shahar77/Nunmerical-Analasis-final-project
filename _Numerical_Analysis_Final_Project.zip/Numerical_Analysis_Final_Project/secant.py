"""
Secant Method for solving nonlinear equations.
"""

import matplotlib.pyplot as plt
import numpy as np


def secant_method(f, x0, x1, tol=1e-6, max_iter=100):
    """
    Applies the Secant method to find a root of f.

    Parameters:
        f (function): The function f(x).
        x0 (float): First initial guess.
        x1 (float): Second initial guess.
        tol (float): Tolerance for convergence.
        max_iter (int): Maximum number of iterations.

    Returns:
        root (float): Approximate root.
        iterations (list): List of (x_n, f(x_n)) values at each step.
    """
    iterations = [(x0, f(x0)), (x1, f(x1))]

    for _ in range(max_iter):
        f_x0 = f(x0)
        f_x1 = f(x1)

        if f_x1 - f_x0 == 0:
            raise ZeroDivisionError("Zero denominator in secant formula.")

        x2 = x1 - f_x1 * (x1 - x0) / (f_x1 - f_x0)
        iterations.append((x2, f(x2)))

        if abs(x2 - x1) < tol:
            return x2, iterations

        x0, x1 = x1, x2

    raise RuntimeError("Secant method did not converge.")


def plot_secant(f, root, iterations, x_range=None):
    """
    Plots the function and highlights the Secant method iterations.

    Parameters:
        f (function): The function f(x).
        root (float): The root found.
        iterations (list): Iteration points.
        x_range (tuple): Optional (xmin, xmax) for plotting.
    """
    if not x_range:
        xs = [x for x, _ in iterations]
        margin = (max(xs) - min(xs)) * 0.2 or 1
        x_range = (min(xs) - margin, max(xs) + margin)

    x_vals = np.linspace(*x_range, 400)
    y_vals = f(x_vals)

    plt.figure(figsize=(10, 6))
    plt.plot(x_vals, y_vals, label="f(x)")
    plt.axhline(0, color='gray', linestyle='--')

    for x_n, _ in iterations:
        plt.plot(x_n, f(x_n), 'ro', alpha=0.3)

    plt.plot(root, f(root), 'go', label=f'Root ≈ {root:.6f}', markersize=10)
    plt.title("Secant Method")
    plt.xlabel("x")
    plt.ylabel("f(x)")
    plt.legend()
    plt.grid(True)
    plt.show()


# Example usage
if __name__ == "__main__":
    # Define the function
    f = lambda x: x**3 - x - 2

    # Initial guesses
    x0 = 1
    x1 = 2
    tol = 1e-6

    try:
        root, iters = secant_method(f, x0, x1, tol)
        print(f"Approximate root: {root}")
        print(f"Total iterations: {len(iters)}")
        plot_secant(f, root, iters)

    except Exception as e:
        print("Error:", e)
