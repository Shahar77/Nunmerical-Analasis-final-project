"""
Machine Precision (Epsilon) Detection
"""

def find_machine_epsilon():
    """
    Determines the machine epsilon: the smallest number e such that 1.0 + e != 1.0

    Returns:
        float: Machine epsilon
        int: Number of iterations it took to find it
    """
    epsilon = 1.0
    iterations = 0

    while 1.0 + epsilon != 1.0:
        epsilon /= 2
        iterations += 1

    return epsilon * 2, iterations  # return last value before it was too small


def explain_machine_precision():
    """
    Prints and explains the concept of machine precision.
    """
    eps, steps = find_machine_epsilon()
    print(f"Machine epsilon is approximately: {eps:.20f}")
    print(f"It took {steps} halving steps to find it.")
    print("\nThis means that any difference smaller than this epsilon is indistinguishable from zero in float arithmetic.")


# Example usage
if __name__ == "__main__":
    explain_machine_precision()
