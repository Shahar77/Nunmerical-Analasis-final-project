"""
Submenu for Numerical Differentiation
"""

import numpy as np
from methods.numerical_differentiation import (
    forward_difference,
    backward_difference,
    central_difference,
    plot_derivative
)


def get_function_input():
    """
    קולטת פונקציה מהמשתמשת ומחזירה אותה כאובייקט פייתון
    """
    func_str = input("Enter function f(x): ")
    return lambda x: eval(func_str, {"x": x, "np": np})


def differentiation_menu():
    print("\n✏️ Numerical Differentiation")
    print("1. Forward Difference")
    print("2. Backward Difference")
    print("3. Central Difference + Tangent Graph")
    print("0. Return to Main Menu")

    choice = input("Choose method: ").strip()

    if choice in ["1", "2", "3"]:
        f = get_function_input()
        x = float(input("Enter point x: "))
        h = float(input("Enter step size h (e.g. 1e-5): "))

    if choice == "1":
        try:
            result = forward_difference(f, x, h)
            print(f"✅ Forward Difference: f'({x}) ≈ {result:.6f}")
        except Exception as e:
            print("Error:", e)

    elif choice == "2":
        try:
            result = backward_difference(f, x, h)
            print(f"✅ Backward Difference: f'({x}) ≈ {result:.6f}")
        except Exception as e:
            print("Error:", e)

    elif choice == "3":
        try:
            result = central_difference(f, x, h)
            print(f"✅ Central Difference: f'({x}) ≈ {result:.6f}")
            plot_derivative(f, x, h)
        except Exception as e:
            print("Error:", e)

    elif choice == "0":
        return

    else:
        print("Invalid choice.")
        differentiation_menu()
