"""
Submenu for Numerical Integration
"""

import numpy as np
from methods.numerical_integration import trapezoidal_rule, simpson_rule, plot_integral


def get_function_input():
    """
    מקבלת פונקציה בצורה של מחרוזת ומחזירה אותה כפונקציית פייתון
    """
    func_str = input("Enter function f(x): ")
    return lambda x: eval(func_str, {"x": x, "np": np})


def integration_menu():
    print("\n📐 Numerical Integration")
    print("1. Trapezoidal Rule")
    print("2. Simpson's Rule")
    print("0. Return to Main Menu")

    choice = input("Choose method: ").strip()

    if choice in ["1", "2"]:
        f = get_function_input()
        a = float(input("Enter lower bound (a): "))
        b = float(input("Enter upper bound (b): "))
        n = int(input("Enter number of subintervals (n): "))

    if choice == "1":
        try:
            result = trapezoidal_rule(f, a, b, n)
            print(f"✅ Trapezoidal Rule Approximation: {result:.6f}")
            plot_integral(f, a, b, n, method="trapezoidal")
        except Exception as e:
            print("Error:", e)

    elif choice == "2":
        try:
            result = simpson_rule(f, a, b, n)
            print(f"✅ Simpson's Rule Approximation: {result:.6f}")
            plot_integral(f, a, b, n, method="simpson")
        except Exception as e:
            print("Error:", e)

    elif choice == "0":
        return

    else:
        print("Invalid choice.")
        integration_menu()
