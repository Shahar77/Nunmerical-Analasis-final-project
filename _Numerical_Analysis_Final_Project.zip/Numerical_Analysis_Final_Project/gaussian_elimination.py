"""
Gaussian Elimination for solving systems of linear equations.
"""

import numpy as np


def gaussian_elimination(A, b):
    """
    Solves Ax = b using Gaussian Elimination without pivoting.

    Parameters:
        A (ndarray): Coefficient matrix (n x n)
        b (ndarray): Right-hand side vector (n)

    Returns:
        x (ndarray): Solution vector
    """
    A = A.astype(float)  # ensure float division
    b = b.astype(float)
    n = len(b)

    # Forward elimination
    for i in range(n):
        if A[i, i] == 0:
            raise ValueError("Zero pivot encountered!")

        for j in range(i+1, n):
            factor = A[j, i] / A[i, i]
            A[j, i:] -= factor * A[i, i:]
            b[j] -= factor * b[i]

    # Back substitution
    x = np.zeros(n)
    for i in range(n-1, -1, -1):
        x[i] = (b[i] - np.dot(A[i, i+1:], x[i+1:])) / A[i, i]

    return x


# Example usage
if __name__ == "__main__":
    A = np.array([[2, 1, -1],
                  [-3, -1, 2],
                  [-2, 1, 2]], dtype=float)
    b = np.array([8, -11, -3], dtype=float)

    try:
        x = gaussian_elimination(A, b)
        print("Solution vector x:")
        print(x)

    except Exception as e:
        print("Error:", e)
