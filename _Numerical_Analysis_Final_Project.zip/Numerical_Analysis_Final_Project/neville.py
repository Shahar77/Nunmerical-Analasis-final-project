"""
Neville's Method for Polynomial Interpolation
"""

import numpy as np
import matplotlib.pyplot as plt


def neville_interpolation(x_points, y_points, x_val):
    """
    Applies Neville's method to interpolate the value of f(x_val).

    Parameters:
        x_points (list): x coordinates of known points
        y_points (list): y coordinates of known points
        x_val (float): The value at which to interpolate

    Returns:
        float: Interpolated value f(x_val)
        2D list: The full Neville table
    """
    n = len(x_points)
    Q = [[0.0 for _ in range(n)] for _ in range(n)]

    for i in range(n):
        Q[i][0] = y_points[i]

    for j in range(1, n):
        for i in range(n - j):
            Q[i][j] = ((x_val - x_points[i + j]) * Q[i][j - 1] +
                       (x_points[i] - x_val) * Q[i + 1][j - 1]) / \
                      (x_points[i] - x_points[i + j])

    return Q[0][n - 1], Q


def plot_neville(x_points, y_points, resolution=200):
    """
    Plots Neville's interpolation polynomial through the given points.

    Parameters:
        x_points (list): x coordinates of known points
        y_points (list): y coordinates of known points
        resolution (int): Number of interpolation points for plotting
    """
    x_min, x_max = min(x_points), max(x_points)
    x_vals = np.linspace(x_min, x_max, resolution)
    y_vals = [neville_interpolation(x_points, y_points, x)[0] for x in x_vals]

    plt.figure(figsize=(10, 6))
    plt.plot(x_vals, y_vals, label="Neville Polynomial", color="purple")
    plt.scatter(x_points, y_points, color="orange", label="Given Points", zorder=5)
    plt.title("Neville Interpolation")
    plt.xlabel("x")
    plt.ylabel("f(x)")
    plt.legend()
    plt.grid(True)
    plt.show()


# Example usage
if __name__ == "__main__":
    x_pts = [1, 2, 3, 4]
    y_pts = [1, 4, 9, 16]
    x_val = 2.5

    try:
        interpolated_value, table = neville_interpolation(x_pts, y_pts, x_val)
        print(f"Interpolated value at x = {x_val}: {interpolated_value:.6f}")
        print("Neville table:")
        for row in table:
            print(["{:.4f}".format(val) for val in row if val != 0.0])
        plot_neville(x_pts, y_pts)
    except Exception as e:
        print("Error:", e)
