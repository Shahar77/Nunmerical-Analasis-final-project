"""
Main CLI interface for Numerical Methods System
"""

import sys

def main():
    print("\n📊 Welcome to the Numerical Methods System 📊")
    print("Choose a category:")
    print("1. Root Finding Methods")
    print("2. Linear Systems Solvers")
    print("3. Interpolation Methods")
    print("4. Numerical Integration")
    print("5. Numerical Differentiation")
    print("6. Machine Precision Analysis")
    print("0. Exit")

    choice = input("Enter your choice (0–6): ").strip()

    if choice == "1":
        from methods_root import root_menu
        root_menu()

    elif choice == "2":
        from methods_linear import linear_menu
        linear_menu()

    elif choice == "3":
        from methods_interpolation import interpolation_menu
        interpolation_menu()

    elif choice == "4":
        from methods_integration import integration_menu
        integration_menu()

    elif choice == "5":
        from methods_differentiation import differentiation_menu
        differentiation_menu()

    elif choice == "6":
        from methods.machine_precision import explain_machine_precision
        explain_machine_precision()

    elif choice == "0":
        print("Goodbye 👋")
        sys.exit()

    else:
        print("Invalid input. Try again.")
        main()


if __name__ == "__main__":
    main()
