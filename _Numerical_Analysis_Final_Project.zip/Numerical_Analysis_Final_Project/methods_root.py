"""
Submenu for Root Finding Methods
"""

import numpy as np
from methods.bisection import bisection_method, plot_bisection
from methods.newton import newton_raphson, plot_newton
from methods.secant import secant_method, plot_secant


def get_function_input():
    """
    מבקש מהמשתמש להזין פונקציה בצורה של פייתון.
    לדוגמה: x**3 - x - 2
    """
    try:
        func_str = input("Enter function f(x): ")
        f = lambda x: eval(func_str, {"x": x, "np": np})
        return f
    except Exception as e:
        print("Invalid function. Try again.")
        return get_function_input()


def root_menu():
    print("\n🔍 Root Finding Methods")
    print("1. Bisection Method")
    print("2. Newton-Raphson Method")
    print("3. Secant Method")
    print("0. Return to Main Menu")

    choice = input("Choose method: ").strip()

    if choice == "1":
        f = get_function_input()
        a = float(input("Enter start of interval (a): "))
        b = float(input("Enter end of interval (b): "))
        tol = float(input("Enter tolerance (e.g. 1e-6): "))
        try:
            root, steps = bisection_method(f, a, b, tol)
            print(f"✅ Root found: {root:.6f}")
            print(f"Iterations: {len(steps)}")
            plot_bisection(f, a, b, root, steps)
        except Exception as e:
            print("Error:", e)

    elif choice == "2":
        f = get_function_input()
        df = get_function_input()
        x0 = float(input("Enter initial guess: "))
        tol = float(input("Enter tolerance: "))
        try:
            root, steps = newton_raphson(f, df, x0, tol)
            print(f"✅ Root found: {root:.6f}")
            print(f"Iterations: {len(steps)}")
            plot_newton(f, root, steps)
        except Exception as e:
            print("Error:", e)

    elif choice == "3":
        f = get_function_input()
        x0 = float(input("Enter first guess: "))
        x1 = float(input("Enter second guess: "))
        tol = float(input("Enter tolerance: "))
        try:
            root, steps = secant_method(f, x0, x1, tol)
            print(f"✅ Root found: {root:.6f}")
            print(f"Iterations: {len(steps)}")
            plot_secant(f, root, steps)
        except Exception as e:
            print("Error:", e)

    elif choice == "0":
        return

    else:
        print("Invalid choice.")
        root_menu()
