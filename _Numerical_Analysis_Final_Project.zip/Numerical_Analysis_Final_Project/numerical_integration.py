"""
Numerical Integration Methods: Trapezoidal Rule and Simpson's Rule
"""

import numpy as np
import matplotlib.pyplot as plt


def trapezoidal_rule(f, a, b, n):
    """
    Approximate the integral of f(x) from a to b using the Trapezoidal Rule.

    Parameters:
        f (function): Function to integrate
        a (float): Start of interval
        b (float): End of interval
        n (int): Number of subintervals

    Returns:
        float: Approximate integral value
    """
    h = (b - a) / n
    x = np.linspace(a, b, n + 1)
    y = f(x)
    return (h / 2) * (y[0] + 2 * np.sum(y[1:n]) + y[n])


def simpson_rule(f, a, b, n):
    """
    Approximate the integral of f(x) from a to b using Simpson's Rule.

    Parameters:
        f (function): Function to integrate
        a (float): Start of interval
        b (float): End of interval
        n (int): Number of subintervals (must be even)

    Returns:
        float: Approximate integral value
    """
    if n % 2 != 0:
        raise ValueError("Simpson's rule requires an even number of intervals.")

    h = (b - a) / n
    x = np.linspace(a, b, n + 1)
    y = f(x)

    return (h / 3) * (y[0] + 4 * np.sum(y[1:n:2]) + 2 * np.sum(y[2:n-1:2]) + y[n])


def plot_integral(f, a, b, n, method='trapezoidal'):
    """
    Plots the function and shaded area under the curve using the chosen method.

    Parameters:
        f (function): Function to integrate
        a (float): Start of interval
        b (float): End of interval
        n (int): Number of subintervals
        method (str): 'trapezoidal' or 'simpson'
    """
    x_vals = np.linspace(a, b, 1000)
    y_vals = f(x_vals)

    plt.figure(figsize=(10, 6))
    plt.plot(x_vals, y_vals, label='f(x)', color='blue')
    plt.fill_between(x_vals, y_vals, alpha=0.3, color='skyblue')
    plt.title(f"{method.capitalize()} Rule: Area under f(x)")
    plt.xlabel("x")
    plt.ylabel("f(x)")
    plt.grid(True)
    plt.legend()
    plt.show()


# Example usage
if __name__ == "__main__":
    f = lambda x: np.sin(x)
    a, b = 0, np.pi
    n = 10

    try:
        trap = trapezoidal_rule(f, a, b, n)
        simp = simpson_rule(f, a, b, n)
        print(f"Trapezoidal approximation: {trap:.6f}")
        print(f"Simpson approximation: {simp:.6f}")
        plot_integral(f, a, b, n, method="simpson")
    except Exception as e:
        print("Error:", e)
