"""
Gauss-Seidel Iterative Method for solving systems of linear equations.
"""

import numpy as np


def gauss_seidel(A, b, x0=None, tol=1e-6, max_iter=100):
    """
    Solves Ax = b using the Gauss-Seidel iterative method.

    Parameters:
        A (ndarray): Coefficient matrix (n x n)
        b (ndarray): Right-hand side vector (n)
        x0 (ndarray): Initial guess (default: zero vector)
        tol (float): Convergence tolerance
        max_iter (int): Maximum number of iterations

    Returns:
        x (ndarray): Approximate solution
        history (list): Iteration history of solution vectors
    """
    n = A.shape[0]
    x = np.zeros(n) if x0 is None else x0.copy()
    history = [x.copy()]

    for _ in range(max_iter):
        x_new = x.copy()
        for i in range(n):
            sum1 = np.dot(A[i, :i], x_new[:i])    # values already updated
            sum2 = np.dot(A[i, i+1:], x[i+1:])    # old values
            x_new[i] = (b[i] - sum1 - sum2) / A[i, i]

        history.append(x_new.copy())
        if np.linalg.norm(x_new - x, ord=np.inf) < tol:
            return x_new, history

        x = x_new

    raise RuntimeError("Gauss-Seidel method did not converge.")


# Example usage
if __name__ == "__main__":
    A = np.array([[4, 1, 2],
                  [3, 5, 1],
                  [1, 1, 3]], dtype=float)
    b = np.array([4, 7, 3], dtype=float)
    x0 = np.zeros(3)

    try:
        solution, steps = gauss_seidel(A, b, x0)
        print("Solution vector x:")
        print(solution)
        print(f"Total iterations: {len(steps)}")
    except Exception as e:
        print("Error:", e)
